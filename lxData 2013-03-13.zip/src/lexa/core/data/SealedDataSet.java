/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * SealedDataSet.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: March 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * 2013-03-07   WNW 13-03       Tidy up for initial publication to Code project.
 *================================================================================
 */

package lexa.core.data;

import lexa.core.data.exception.DataException;

/**
 * A read only <tt>DataSet</tt>.
 * @author William
 * @since 2009-08
 * @see
 */
public class SealedDataSet
        extends DataSet {
    /**
     * Constructor for a <tt>SealedDataSet</tt> that wraps the passed data set.
     * No modification can be made to a sealed data set, though it can be cloned.
     * The cloned data set can be modified.
     *
     * @param data  A
     */
    public SealedDataSet(DataSet data) {
        super(data);
    }

    /**
     * Override of {@see DataSet} base implementation for {@see DataSet#get}.
     * <br>
     * If the value is a {@see DataSet} it is wrapped in a {@see SealedDataSet}.
     * @param key The key for the {@see DataItem}.
     * @return The item represented by {@code key}.
     */
    @Override
    public synchronized DataItem get(String key) {
        DataItem item = super.get(key);
        if (item.getType().equals(ValueType.DATA_SET)) {
            return new DataItem(item.getKey(),new SealedDataSet(item.getDataSet()));
        }
        return item;
    }
    /**
     * Override of <tt>DataSet</tt> base implementation for <tt>put</tt>.
     * Throws an <tt>UnsupportedOperationException</tt> if called.
     * @param item  A {@code DataItem}.
     */
    @Override
    public synchronized void put(DataItem item) {
        throw new UnsupportedOperationException(
                        "Cannot change the content of a sealed data list");
    }
    /**
     * Override of <tt>DataSet</tt> base implementation for <tt>remove</tt>.
     * Throws an <tt>UnsupportedOperationException</tt> if called.
     * @param key
     */
    @Override
    public synchronized DataItem remove(String key) {
        throw new UnsupportedOperationException(
                        "Cannot change the content of a sealed data list");
    }
}
