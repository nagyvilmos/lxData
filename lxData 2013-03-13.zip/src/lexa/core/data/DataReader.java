/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * DataReader.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: February 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * DD-MON-YY    ??
 *================================================================================
 */

package lexa.core.data;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;

/**
 * Read {@see DataItem} and {@see DataSet} objects from an input stream.
 * <p>A {@code DataSet} is read as a series of {@code DataItem} objects.
 * <p>A {@code DataItem} is read as the name followed by the formatted value;
 * with the format depends on the data type.
 * <p>See {@see DataWriter} for the format used.
 *
 * @author William
 * @since 2013-02
 */
public class DataReader {
    /** The reader used to input the content */
    private final BufferedReader bufferedReader;
    private final boolean fromFile;
    /**
     * Create a new reader to input directly from a file.
     *
     * @param   file
     *      The file for receiving the input.
     * @throws  FileNotFoundException
     *      When the file to be opened cannot be accessed.
     */
    public DataReader (File file)
            throws FileNotFoundException {
        this(new BufferedReader(
                new InputStreamReader(
                new DataInputStream(
                new FileInputStream(file)))),
                true);
    }

    /**
     * Create a new reader to input from a buffer.
     *
     * @param   bufferedReader
     *      The buffer for reading data from.
     */
    public DataReader (BufferedReader bufferedReader) {
        this(bufferedReader, false);
    }

    /**
     * Create a new reader to input from a buffer.
     *
     * @param   bufferedReader
     *      The buffer for reading data from.
     * @param   fromFile
     *      Indicates the reader is from a file.
     */
    private DataReader (BufferedReader bufferedReader, boolean fromFile) {
        this.bufferedReader = bufferedReader;
        this.fromFile = fromFile;
    }

    /**
     * Close the input.
     * <br>
     * Once the input has been closed, no more data may be read.
     *
     * @throws  IOException
     *       When an IO error occurs closing the input.
     */
    public void close()
            throws IOException {
        this.bufferedReader.close();
    }

    /**
     * Read the input into a {@see DataSet}.
     *
     * @return
     *       A {@see DataSet} read from the input, null if empty.
     * @throws  IOException
     *       When an IO error occurs closing the input.
     */
    public DataSet read()
            throws IOException {
        return this.read(false);
    }

    /**
     * Read a {@see DataSet} from the input.
     *
     * @param   isNested
     *       Indicate that the read is inside a {@see DataSet}
     *       and so should not reach EOF.
     * @return
     *       A {@see DataSet} read from the input, null if empty
     *       and {@code isNested == true}.
     * @throws  IOException
     *       When an IO error occurs reading the input.
     */
    private DataSet read(boolean isNested)
            throws IOException {
        DataSet data = new DataSet();

        while (true) {
            DataItem item = this.readItem(isNested);
            if (item == null) {
                break;
            }
            data.put(item);
        }
        if (!isNested && data.isEmpty()) {
            return null; // do not return an empty data set or else we can't read it all.
        }
        return data;
    }

    /**
     * Read a {@see DataItem} from the input.
     *
     * @param   isNested
     *       Indicate that the read is inside a {@see DataSet}
     *       and so should not reach EOF.
     * @return
     *       A {see DataItem} read from the input or {@code null} if
     *       The current {@see DataSet} has all been read.
     * @throws  IOException
     *       When an IO error occurs reading the input.
     */
    private DataItem readItem(boolean isNested)
            throws IOException {
        String line;
        while (true) {
            line = this.bufferedReader.readLine();
            if (line == null) {
                if (isNested) {
                    throw new IOException("Expected '}' before EOF.");
                }
                return null;
            }

            line = line.trim();
            if (line.isEmpty() || line.charAt(0) == '#') {
                continue;
            } else if ("}".equals(line)) {
                if (!isNested) {
                    throw new IOException("Expected EOF.");
                }
                return null;
            }
            break;
        }

        // split the line at the first space
        int split = line.indexOf(' ');
        if (split == -1) {
            // blank value
            return new DataItem(line, null);
        }

        String key = line.substring(0, split);
        String value = line.substring(split).trim();

        // ignore includes if we're not reading from a file.
        if (this.fromFile &&
                value.length() > 9 &&
                "@include ".equals(value.substring(0,9))) {
            value = value.substring(9).trim();
            File includeFile = new File(value);
            if (!includeFile.exists()) {
                // push the path in front:
                includeFile = new File(
                        System.getProperty("user.dir") + "\\data\\" + value);
            }
            DataReader include = new DataReader(includeFile);
            DataSet data = include.read();
            include.close();
            return new DataItem(key, data);
        }

        char type = value.charAt(0);
        if (value.length() == 1) {
            if ('{' == type) {
                return new DataItem(key,this.read(true));
            }
            if ('\\' == type) {
                return new DataItem(key, this.readCodedString());
            }
        }
        if (' ' == value.charAt(1)) {
            if ('-' == type) {
                return new DataItem(key, value.substring(2));
            }
            if ('$' == type) {
                return new DataItem(key, Double.parseDouble(value.substring(2)));
            }
            if ('%' == type) {
                return new DataItem(key, Integer.parseInt(value.substring(2)));
            }
            if ('?' == type) {
                if ("? TRUE".equals(value)) {
                    return new DataItem(key, true);
                }
                if ("? FALSE".equals(value)) {
                    return new DataItem(key, false);
                }
                throw new IOException("Boolean values are TRUE or FALSE");
            }
            if ('@' == type) {
                //date hadling needs a special set of functions.
                return new DataItem(key, Date.parse(value.substring(2)));
            }
        }
        // just treat unqualified as a string.
       return new DataItem(key, value);
    }

    /**
     * Read a coded string from the input.
     * <p>Example:
     * <pre>
     * \# this will all be read as\
     * it \@ contains all the special chracters such as \\ are escaped\
     * \{ so the parser can read them \}.\
     * all for \$15.00 \@ \-50\% discount
     * </pre>
     *
     * @return A decoded string.
     * @throws  IOException
     *       When an IO error occurs reading the input.
     */
    private String readCodedString()
            throws IOException {
        StringBuilder builder = new StringBuilder();
        boolean more = true;
    	while (more) {
            String line = this.bufferedReader.readLine();
            if (line == null) {
                throw new IOException("Incomplete coded string.");
            }
            more = false;
            for (int c = 0;
                    c < line.length();
                    c++) {
                char ch = line.charAt(c);
                if ('\\' == ch) {
                    c++;
                    if (c == line.length()) {
                        more = true;
                        builder.append('\n');
                        break;
                    }
                    ch = line.charAt(c);
                }
                builder.append(ch);
            }
    	}
    	return builder.toString();
    }

}
