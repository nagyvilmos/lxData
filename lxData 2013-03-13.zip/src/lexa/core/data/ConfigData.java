/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * ConfigData.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: July 2012
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * 28-FEB-13    WNW 2013-03     add getItem(String) so that config can
 *                              include native non-string values.
 *================================================================================
 */
package lexa.core.data;

import java.util.HashSet;
import java.util.Set;
import lexa.core.data.exception.DataException;

/**
 * A container for a {@see DataSet} as configuration.
 * <br>
 * This is used for loading and parsing configuration items. Once read, the object should be closed to ensure
 *
 * @author William
 */
public class ConfigData {

    /** Data containing all the configuration items. */
    private final DataSet data;
    /** The set of processed keys */
    private final Set<String> read;
    /** The parent containing this branch. */
    private ConfigData parent;
    /** The current path. */
    private final String path;
    /** The name of the block. */
    private final String block;
    /** Indicates if the block is open or not */
    private boolean isOpen;

    /**
     * Create a new configuration.
     * <br>
     * The ConfigData will contain all the elements in the data set.
     * The current path of the configuration is set to  {@code root}.
     *
     * @param data A {@code DateSet} containing the configuration data.
     *
     * @throws DataException The {@code data} is null or empty.
     */
    public ConfigData(DataSet data)
            throws DataException {
        this(data, "root");
    }

    /**
     * Create a new configuration.
     * <br>
     * The ConfigData will contain all the elements in the data set.
     *
     * @param data A {@code DateSet} containing the configuration data.
     * @param path The path for the configuration.
     *
     * @throws DataException The {@code path} is null or empty, or the {@code data} is null or empty.
     */
    public ConfigData(DataSet data, String path)
            throws DataException {
        this(data, null, path);
    }

    /**
     * Create a new configuration.
     * <br>
     * The ConfigData will contain all the elements in the data set.
     *
     * @param data   A {@code DateSet} containing the configuration data.
     * @param parent The parent that contained the configuration.
     * @param block  The block within the parent where the configuration comes from
     *
     * @throws DataException The {@code block} is null or empty, or the {@code data} is null or empty.
     */
    private ConfigData(DataSet data, ConfigData parent, String block)
            throws DataException {
        // are the arguments valid?
        if (block == null || "".equals(block)) {
            if (parent == null) {
                throw new DataException("No path supplied");
            } else {
                throw new DataException("No path supplied", parent.path);
            }
        }

        if (data == null || data.isEmpty()) {
            if (parent == null) {
                throw new DataException("No data in configuration", block);
            } else {
                throw new DataException("No path supplied", parent.path, block);
            }
        }

        // populate the config
        this.parent = parent;
        this.block = block;
        if (this.parent == null) {
            this.path = block;
        } else {
            this.path = this.parent.path + "." + this.block;
        }
        // clone the data to prevent
        this.data = new DataSet(data);
        this.read = new HashSet<String>();
        this.isOpen = true;
    }

    /**
     * Close the configuration after reading.
     *
     * @throws DataException All the configuration items have not been read.
     */
    public void close()
            throws DataException {
        if (!this.isConfigRead()) {
            throw new DataException("All config data not read", this.path);
        }
        if (this.parent != null) {
            this.parent.close(this.block);
            this.parent = null;
        }
    }

    /**
     * Close a child block of the configuration.
     *
     * @param key The key to the block.
     *
     * @throws DataException The block has already been closed.
     */
    private void close(String key)
            throws DataException {
        if (this.data.getDataSet(key) == null) {
            throw new DataException("Cannot close block", key, this.path);
        }
        this.read.add(key);
    }

    /**
     * Get a configuration block from the configuration. Gets the block for the named key.
     *
     * @param key The key that identifies the block.
     *
     * @return The block represented by {@code key}
     *
     * @throws DataException The block does not exist within the configuration.
     */
    public ConfigData getConfigData(String key)
            throws DataException {
        DataSet item = this.data.getDataSet(key);
        if (item == null) {
            throw new DataException("Missing config block", key, path);
        }
        return new ConfigData(item, this, key);
    }

    /**
     * Get a configuration item from the configuration.
     * <br>
     * Gets the {@see DataItem} for the named key.
     *
     * @param key The key that identifies the item.
     *
     * @return The block represented by {@code key}
     *
     * @throws DataException The block does not exist within the configuration.
     */
    public DataItem getItem(String key)
            throws DataException {
        DataItem item = this.data.get(key);
        if (item == null) {
            throw new DataException("Missing item", key, path);
        }
        this.read.add(key);
        return item;
    }

    /**
     * Get an optional string value from the configuration.
     * <br>
     * Gets the value for the named key, if the value does not
     * exist then a null is returned.
     *
     * @param key The key that identifies the item.
     *
     * @return The value of the item represented by {@code key} or {@code null} if it does not exist.
     */
    public String getOptionalSetting(String key) {
        String item;
        try {
            item = this.getSetting(key);
        } catch (DataException ex) {
            // no need as this is an optional item.
            // as it's missing, we just return null.
            return null;
        }

        return item;
    }

    /**
     * Get an optional string value from the configuration.
     * <br>
     * Gets the value for the named key, if the value does not
     * exist then the {@code defaultValue} is returned.
     *
     * @param key The key that identifies the item.
     * @param defaultValue The default value if the item does not exist.
     *
     * @return  The value of the item represented by {@code key},
     *          or {@code defaultValue} if it does not exist.
     */
    public String getOptionalSetting(String key, String defaultValue) {
        String item = this.getOptionalSetting(key);
        if (item == null) {
            return defaultValue;
        }

        return item;
    }

    /**
     * Get a string value from the configuration.
     * <br>
     * Gets the value for the named key.
     *
     * @param key The key that identifies the item.
     *
     * @return The value of the item represented by {@code key}.
     *
     * @throws DataException The value does not exist within the configuration.
     */
    public String getSetting(String key)
            throws DataException {
        String item = this.data.getString(key);
        if (item == null) {
            throw new DataException("Missing setting", key, path);
        }
        this.read.add(key);

        return item;
    }

    /**
     * indicates if all the elements have been read.
     *
     * @return true if all of the elements have been read.
     */
    public boolean isConfigRead() {
        return (this.data.size() == this.read.size());
    }

    /**
     * Get the list of keys for the configuration block.
     *
     * @return An array containing all the keys.
     *
     * @throws DataException The configuration block is empty.
     */
    public String[] keys()
            throws DataException {
        return this.data.keys();
    }
}
