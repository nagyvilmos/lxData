/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * DataSet.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: July 2009
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * DD-MON-YY    ??
 *================================================================================
 */

package lexa.core.data;

import java.util.ArrayList;
import java.util.Date;

/**
 * Provide a polymorphic map containing disparate data types as values.
 * A {@see DataSet} contains multiple {@see DataItem} objects, keyed by
 * their names.
 * @author William
 * @since 2009-07
 * @see DataItem
 */
public class DataSet {

    private ArrayList<DataItem> items;
    private int last;
    /**
     * Create a new {@see DataSet} with no entries.
     */
    public DataSet() {
        this.items = new ArrayList<DataItem>();
        this.last  = 0;
    }

    /**
     * Create a new {@see DataSet} containing a cloned list of entries.
     * @param clone The {@see DataSet} to clone.
     */
    public DataSet(DataSet clone) {
        this();
        //this.items = dataList.items.clone();
        for (DataItem item : clone.items) {
            this._put(new DataItem(item));
        }
    }

    @Override
    public DataSet clone() {
        return new DataSet(this);
    }

    /**
     * Find an item in the data set.
     * @param key
     * @return
     */
    public synchronized int find(String key) {
        if (this.items.size() > 0) {
            int end;
            if (this.last < this.items.size()) {
                end = this.last;
            } else {
                end = 0;
            }
            int index = end;
            do {
                if (this.items.get(index).getKey().equals(key)) {
                    this.last = index;
                    return index;
                }
                index = (index + 1) % this.items.size();
            } while (index != end);

        }
        return -1;
    }
    /**
     * Get a {@see DataItem} from the list for the supplied key.
     * @param key The key for the {@see DataItem}.
     * @return A {@see DataItem} if it exists, otherwise {@code null}.
     */
    public synchronized DataItem get(String key) {
        int index = this.find(key);
        if (index == -1) {
            return null;
        }
        return this.items.get(index);
    }

    /**
     * Get a {@see String} from the list for the supplied key.
     * @param key The key for the {@see DataItem}.
     * @return If the item exists and is a {@see String} then the
     * item's value, otherwise {@code null}.
     */
    public synchronized Boolean getBoolean(String key) {
        DataItem item = this.get(key);
        return (item == null) ?
                null :
                item.getBoolean();
    }

    /**
     * Get a {@see DataSet} from the list for the supplied key.
     * @param key The key for the {@see DataItem}.
     * @return If the item exists and is a {@see DataSet} then the
     * item's value, otherwise {@code null}.
     */
    public synchronized DataSet getDataSet(String key) {
        DataItem item = this.get(key);
        return (item == null) ?
                null :
                item.getDataSet();
    }

    /**
     * Get a {@see Date} from the list for the supplied key.
     * @param key The key for the {@see Date}.
     * @return If the item exists and is a {@see Date} then the
     * item's value, otherwise {@code null}.
     */
    public synchronized Date getDate(String key) {
        DataItem item = this.get(key);
        return (item == null) ?
                null :
                item.getDate();
    }

    /**
     * Get a {@see String} from the list for the supplied key.
     * @param key The key for the {@see DataItem}.
     * @return If the item exists and is a {@see String} then the
     * item's value, otherwise {@code null}.
     */
    public synchronized Integer getInteger(String key) {
        DataItem item = this.get(key);
        return (item == null) ?
                null :
                item.getInteger();
    }

    /**
     * Get a {@see String} from the list for the supplied key.
     * @param key The key for the {@see DataItem}.
     * @return If the item exists and is a {@see String} then the
     * item's value, otherwise {@code null}.
     */
    public synchronized String getString(String key) {
        DataItem item = this.get(key);
        return (item == null) ?
                null :
                item.getString();
    }

        /**
     * Get an {@see Object} from the list for the supplied key.
     * @param key The key for the {@see Object}.
     * @return If the item exists then the
     * item's value, otherwise {@code null}.
     */
    public synchronized Object getValue(String key) {
        DataItem item = this.get(key);
        if (item == null) {
            return null;
        }
        return item.getValue();
    }

    /**
     * Returns true if this contains no elements.
     * @return true if this contains no elements
     */
    public synchronized boolean isEmpty() {
        return (this.items.isEmpty());
    }

    /**
     * Get the list of keys.
     *
     * @return An array containing all the keys.
     */    public synchronized String[] keys() {
        String[] keys = new String[this.items.size()];
        for (int item = 0;
                item < this.items.size();
                item++) {
            keys[item] = this.items.get(item).getKey();
        }
        return keys;
    }

    /**
     * Implementation for {@see #put(DataItem)}.
     * <br>
     * This is {@code private} to stop any overrides and is to be called only
     * from this and the constructor {@see #DataSet(DataSet)}.
     * @param item A {@see DataItem} to add.
     */
    private void _put(DataItem item) {
        if (item == null) {
            return;
        }
        int index = this.find(item.getKey());
        if (index == -1) {
            this.items.add(item);
        } else {
            this.items.set(index, item);
        }
    }

    /**
     * Put the supplied item into the {@see DataSet}.
     * <br>
     * If the item already exists it is overwritten.
     *
     * @param item A {@see DataItem} to add.
     */
    public synchronized void put(DataItem item) {
        this._put(item);
    }

    /**
     * Put the supplied object into the {@see DataSet}
     * using the supplied key.
     * <br>
     * If the item already exists it is overwritten.
     *
     * @param key The key name for the item
     * @param value The object value to add.
     */
    public synchronized void put(String key, Object value) {
        this.put(new DataItem(key, value));
    }

    /**
     * Put the contents of another {@see DataSet} into this one.
     * <br>
     * Any items in the new data set that have a key that matches another item
     * will overwrite the existing item.
     *
     * @param data The data to be added.
     */
    public synchronized void put(DataSet data) {
        for (DataItem item : data.items) {
            this.put(item);
        }
    }

    /**
     * Removes the specified element from this {@see DataSet}.
     * <br>
     * Shifts any subsequent elements to the left (subtracts one from their indices).
     *
     * @param key   the key to the item to remove
     *
     * @return the element that was removed
     */
    public synchronized DataItem remove(String key) {
        int index = this.find(key);
        if (index == -1) {
            return null;
        }
        return this.items.remove(index);
    }

    /**
     * Get the size of the {@see DataSet}.
     *
     * @return the number of {@see DataItem} objects in the {@see DataSet}
     */
    public synchronized int size() {
        return this.items.size();
    }

    /**
     * Return a string representation of a {@see DataSet}.
     * Formatted as a list of all the {@see DataItem}'s:
     * <blockquote>
     * <pre>
     * {{key}{value} {key}{{key}{value} {key}{value}}}
     * </pre></blockquote>
     *
     * @return A string representation of the object.
     */
    @Override
    public synchronized String toString() {
        StringBuilder sb = new StringBuilder("{");
        for (DataItem di : this.items) {
            sb.append("{").append(di.toString()).append("}");
        }
        return sb.append("}").toString();
    }
}
