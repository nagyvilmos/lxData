/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lexa.core.data.persistance;

/**
 *
 * @author William
 * @since YYYY-MM
 */
public class FormatString
        implements Format<String> {

    @Override
    public String toString(String value) {
        return value.replace("\\", "\\\\")
                            .replace("#", "\\#")
                            .replace("-", "\\-")
                            .replace("\"", "\\\"")
                            .replace("{", "\\{")
                            .replace("}", "\\}")
                            .replace("?", "\\?")
                            .replace("$", "\\$")
                            .replace("@", "\\@")
                            .replace("%", "\\%")
                            .replace("\n", "\\\n");
    }

    @Override
    public String fromString(String string) {
        return string;
    }
}
