/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lexa.core.data.persistance;

import java.text.NumberFormat;
import java.util.Locale;

/**
 *
 * @author William
 * @since YYYY-MM
 */
public class DoubleFormat
        implements Format<Double> {
    private NumberFormat numberFormat;

    public DoubleFormat() {
        this(Locale.ENGLISH);
    }
    public DoubleFormat(Locale locale) {
        this.numberFormat = NumberFormat.getNumberInstance(locale);
    }

    @Override
    public String toString(Double value) {
        return this.numberFormat.format(value);
    }

    @Override
    public Double fromString(String string) {

        try {
            return this.numberFormat.parse(string).doubleValue();
        } catch (Exception ex) {
            // if we can't fromString it, return null
            return null;
        }
    }
}