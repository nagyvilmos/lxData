/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * package-info.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: March 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * 2013-03-07   WNW 13-03       Tidy up for initial publication to Code project.
 * 2013-07-11   WNW 13-07       Bug fix in SealedDataSet
 *================================================================================
 */

/**
 * Provides the classes for managing a polymorphic set of data.
 *
 * @author William N-W
 * @since 2009-07
 */
package lexa.core.data;
