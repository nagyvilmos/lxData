/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * DataWriter.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: MArch 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * DD-MON-YY    ??
 *================================================================================
 */

package lexa.core.data;

import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

/**
 * Write {@see DataItem} and {@see DataSet} objects to an output stream.
 * <p>A {@code DataSet} is written as a series of {@code DataItem} objects.
 * <p>A {@code DataItem} is written as the name followed by the formatted value;
 * with the format depends on the data type.
 * <p>The format of the output is:
 * <pre>
 * # comments can be added at any point and each
 * # item is written thus:
 * # name t value
 * example {
 * # Boolean -
 *    isMale ? TRUE
 * # DataSet -
 *    subBlock {
 *       item - simple text.
 *    }
 * # Date -
 *    dateWriten @ 2013-02-27 12:00:25.3789Z
 * # Double -
 *    weight $ 75.3
 * # Integer -
 *    age % 42
 * # String [without reserved characters] -
 *    name - William Norman-Walker
 * # String [with reserved chracters] -
 *    longText \
 * \# this will all be read as\
 * it \@ contains all the special chracters \\ escaped\
 * \{ so the parser can read them \}.\
 * all for \$15.00 \@ \-50\% discount
 * }
 * # [example ended]
 * </pre>
 *
 * @author William
 * @since 2013-02
 */
public class DataWriter {
    /** The writer used to output the content */
    private final BufferedWriter bufferedWriter;

    /**
     * Create a new writer to output directly to a file.
     *
     * @param   file
     *      The file for directing the output.
     * @throws  FileNotFoundException
     *      When the file to be opened cannnot be accessed.
     */
    public DataWriter (File file)
            throws FileNotFoundException {
        this(new BufferedWriter(
                new OutputStreamWriter(
                new DataOutputStream(
                new FileOutputStream(file)))));
    }

    /**
     * Create a new writer to output to a buffer.
     *
     * @param   writer
     *      The buffer for writing data into.
     */
    public DataWriter (BufferedWriter writer) {
        this.bufferedWriter = writer;
    }

    /**
     * Close the output.
     * <br>
     * Once the output has been closed, no more data may be written.
     *
     * @throws  IOException
     *       When an IO error occurs closing the output.
     */
    public void close()
            throws IOException {
        this.bufferedWriter.close();
    }

    /**
     * Write a comment to the output.
     * <br>
     * Comments are written to the output prefixing each line with the # character.
     * When read back using a {@see DataReader} comments are ignored.
     *
     * @param   comment
     *       The comment to be written to the output.
     * @throws  IOException
     *       When an IO error occurs writing to the output.
     */
    public void comment(String comment)
            throws IOException {
        this.bufferedWriter.write("# ");
        this.bufferedWriter.write(comment.replaceAll("\n", "\n# "));
        this.bufferedWriter.newLine();
        this.bufferedWriter.flush();
    }

    /**
     * Write a {@see DataSet} to the file.
     * <br>
     * Each {@see DataItem} is written to the output using {@see write(DataItem)}.
     *
     * @param   data
     *       The {@see DataSet} to be written to the output.
     * @throws  IOException
     *       When an IO error occurs writing to the output.
     */
    public void write(DataSet data)
            throws IOException {
        this.write(data, new Indent());
        this.bufferedWriter.newLine();
        this.bufferedWriter.flush();
    }

    /**
     * Performs the actual writing.
     * This private method includes the indentation and
     * is also called from {@see write(DataItem, Indent)}.
     *
     * @param   data
     *       The {@see DataSet} to be written to the output.
     * @param   indent
     *       The {@see DataWriter.Indent} to prefix the output.
     * @throws  IOException
     *       When an IO error occurs writing to the output.
     */
    private void write(DataSet data, Indent indent)
            throws IOException {
                String[] keys = data.keys();
        for (int index = 0;
                index < keys.length;
                index++) {
            this.write(data.get(keys[index]), indent);
        }
        this.bufferedWriter.flush();
    }

    /**
     * Write a {@see DataItem} to the output.
     *
     * @param   item
     *       The {@see DataItem} to be written to the output.
     * @throws  IOException
     *       When an IO error occurs writing to the output.
     */
    public void write(DataItem item)
            throws IOException {
         this.write(item, new Indent());
    }

    /**
     * Performs the actual writing.
     * This private method includes the indentation.
     *
     * @param   item
     *       The {@see DataItem} to be written to the output.
     * @param   inden
     *       The {@see DataWriter.Indent} to prefix the output.
     * @throws  IOException
     *       When an IO error occurs writing to the output.
     */
    private void write(DataItem item,Indent indent)
            throws IOException {
        this.bufferedWriter.write(indent.prefix);
        this.bufferedWriter.write(item.getKey());
        switch (item.getType()) {
            case NULL : {
                break;
            }
            case DATA_SET : {
                this.bufferedWriter.write(" {");
                this.bufferedWriter.newLine();
                this.write(item.getDataSet(), indent.next());
                this.bufferedWriter.write(indent.prefix);
                this.bufferedWriter.write('}');
                break;
            }
            case BOOLEAN : {
                this.bufferedWriter.write(" ? ");
                this.bufferedWriter.write(item.getBoolean() ? "TRUE" : "FALSE");
                break;
            }
            case DOUBLE : {
                this.bufferedWriter.write(" $ ");
                this.bufferedWriter.write(item.getDouble().toString());
                break;
            }
            case DATE : {
                this.bufferedWriter.write(" @ ");
                this.bufferedWriter.write(item.getDate().toString());
                break;
            }
            case INTEGER : {
                this.bufferedWriter.write(" % ");
                this.bufferedWriter.write(item.getInteger().toString());
                break;
            }
            default : {
                // escape special characters such as - \" { } ? $ @ % \\ \n
                String value = item.getValue().toString();
                String out = value.replace("\\", "\\\\")
                            .replace("#", "\\#")
                            .replace("-", "\\-")
                            .replace("\"", "\\\"")
                            .replace("{", "\\{")
                            .replace("}", "\\}")
                            .replace("?", "\\?")
                            .replace("$", "\\$")
                            .replace("@", "\\@")
                            .replace("%", "\\%")
                            .replace("\n", "\\\n");
                if (out.length() == value.length()) {
                    this.bufferedWriter.write(" - ");
                    this.bufferedWriter.write(value);
                } else {
                    this.bufferedWriter.write(" \\");
                    this.bufferedWriter.newLine();
                    this.bufferedWriter.write(out);
                }
            }
        }
        this.bufferedWriter.newLine();
    }


    /**
     * Provide indentation or the witter.
     * An indent of {@see INDENT_SIZE} characters per level.
     */
    private class Indent {
        private static final int INDENT_SIZE = 3;
        private final int level;
        private final char[] prefix;

        /**
         * Create a 0 level indentation - 0 characters deep.
         */
        private Indent() {
            this(0);
        }


        /**
         * Create an Indent.
         *
         * @param   level
         *      The level of the indent.
         */
        private Indent(int level) {
            this.level = level;
            this.prefix = new char[level * Indent.INDENT_SIZE];
            for (int c = 0;
                    c < this.prefix.length;
                    c++) {
                prefix[c] = ' ';
            }
        }

        /**
         * Create an indent at the next level.
         *
         * @return
         *      The next level of Indent
         */
        private Indent next() {
            return new Indent(this.level+1);
        }
    }
}
